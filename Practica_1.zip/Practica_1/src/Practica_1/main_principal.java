package Practica_1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;

public class main_principal {

    private static final String ARCHIVO_PRODUCTOS = "productos.txt";
    private static final String ARCHIVO_VENTAS = "ventas.txt";

    private static final Scanner entrada = new Scanner(System.in);
    private static final List<Producto> productos = new ArrayList<>();

    private static int siguientePedido = 1;

    public static void main(String[] args) {

        cargarProductos();
        cargarNumeroPedido();

        int opcion;

        do {
            System.out.println("\n========================================");
            System.out.println("             EL BUEN SABOR");
            System.out.println("       Sistema de gestión de pedidos");
            System.out.println("========================================");
            System.out.println("1. Registrar producto");
            System.out.println("2. Ver inventario");
            System.out.println("3. Reponer stock");
            System.out.println("4. Registrar pedido");
            System.out.println("5. Consultar ventas");
            System.out.println("6. Productos más vendidos");
            System.out.println("0. Salir");
            System.out.println("========================================");

            opcion = leerEntero("Seleccione una opción: ");

            switch (opcion) {
                case 1:
                    registrarProducto();
                    break;
                case 2:
                    verInventario();
                    break;
                case 3:
                    reponerStock();
                    break;
                case 4:
                    registrarPedido();
                    break;
                case 5:
                    consultarVentas();
                    break;
                case 6:
                    mostrarMasVendidos();
                    break;
                case 0:
                    System.out.println("Gracias por utilizar El Buen Sabor.");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }

        } while (opcion != 0);

        entrada.close();
    }

    private static void registrarProducto() {

        System.out.println("\n--- REGISTRAR PRODUCTO ---");

        System.out.print("Código: ");
        String codigo = entrada.nextLine().trim();

        System.out.print("Nombre: ");
        String nombre = entrada.nextLine().trim();

        double precio = leerDecimal("Precio: ");
        int stock = leerEntero("Stock inicial: ");

        for (Producto p : productos) {
            if (p.getCodigo().equalsIgnoreCase(codigo)) {
                System.out.println("Ya existe un producto con ese código.");
                return;
            }
        }

        try {
            Producto producto = new Producto(codigo, nombre, precio, stock);
            productos.add(producto);
            guardarProductos();

            System.out.println("Producto registrado correctamente.");

        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
            productos.removeIf(p -> p.getCodigo().equalsIgnoreCase(codigo));
        } catch (IOException e) {
            System.out.println("No se pudo guardar el producto.");
        }
    }

    private static void verInventario() {

        System.out.println("\n--- INVENTARIO DE PRODUCTOS ---");

        if (productos.isEmpty()) {
            System.out.println("No hay productos registrados.");
            return;
        }

        System.out.printf("%-12s %-25s %12s %10s%n",
                "Código", "Producto", "Precio", "Stock");

        System.out.println("--------------------------------------------------------------");

        for (Producto p : productos) {
            System.out.printf("%-12s %-25s $%11.2f %10d%n",
                    p.getCodigo(),
                    p.getNombre(),
                    p.getPrecio(),
                    p.getStock());
        }
    }

    private static void reponerStock() {

        System.out.println("\n--- REPONER STOCK ---");

        Producto producto = seleccionarProducto();

        if (producto == null) {
            return;
        }

        int cantidad = leerEntero("Cantidad que desea agregar: ");

        try {
            producto.reponerStock(cantidad);
            guardarProductos();

            System.out.println("Stock actualizado correctamente.");
            System.out.println("Stock actual: " + producto.getStock());

        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("No se pudo guardar el stock.");
        }
    }

    private static void registrarPedido() {

        System.out.println("\n--- REGISTRAR PEDIDO ---");

        if (productos.isEmpty()) {
            System.out.println("Primero registre al menos un producto.");
            return;
        }

        String fecha = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                .format(new Date());

        Pedido pedido = new Pedido(siguientePedido, fecha);

        while (true) {

            verInventario();

            Producto producto = seleccionarProducto();

            if (producto == null) {
                if (pedido.getDetalles().isEmpty()) {
                    return;
                }
                break;
            }

            int cantidad = leerEntero("Cantidad: ");

            try {
                pedido.agregarProducto(producto, cantidad);
                System.out.println("Producto agregado al pedido.");

            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
                continue;
            }

            System.out.print("¿Desea agregar otro producto? (s/n): ");
            String respuesta = entrada.nextLine().trim();

            if (!respuesta.equalsIgnoreCase("s")) {
                break;
            }
        }

        if (pedido.getDetalles().isEmpty()) {
            System.out.println("El pedido no contiene productos.");
            return;
        }

        System.out.println("\n--- RESUMEN DEL PEDIDO ---");
        System.out.println("Pedido N.º: " + pedido.getNumero());
        System.out.println("Fecha: " + pedido.getFecha());

        for (Pedido.Detalle d : pedido.getDetalles()) {
            System.out.printf("%s x %d = $%.2f%n",
                    d.getProducto().getNombre(),
                    d.getCantidad(),
                    d.getSubtotal());
        }

        System.out.printf("TOTAL: $%.2f%n", pedido.calcularTotal());

        System.out.print("¿Confirmar pedido? (s/n): ");
        String confirmar = entrada.nextLine().trim();

        if (!confirmar.equalsIgnoreCase("s")) {
            System.out.println("Pedido cancelado.");
            return;
        }

        Map<Producto, Integer> cantidades = new LinkedHashMap<>();

        for (Pedido.Detalle d : pedido.getDetalles()) {
            Producto p = d.getProducto();

            cantidades.put(
                    p,
                    cantidades.containsKey(p)
                            ? cantidades.get(p) + d.getCantidad()
                            : d.getCantidad()
            );
        }

        for (Map.Entry<Producto, Integer> e : cantidades.entrySet()) {
            if (e.getValue() > e.getKey().getStock()) {
                System.out.println("Stock insuficiente para "
                        + e.getKey().getNombre() + ".");
                return;
            }
        }

        try {
            for (Map.Entry<Producto, Integer> e : cantidades.entrySet()) {
                e.getKey().setStock(
                        e.getKey().getStock() - e.getValue());
            }

            guardarProductos();
            guardarVenta(pedido);

            siguientePedido++;

            System.out.println("Pedido registrado correctamente.");

        } catch (IOException e) {
            for (Map.Entry<Producto, Integer> item : cantidades.entrySet()) {
                item.getKey().setStock(
                        item.getKey().getStock() + item.getValue());
            }

            try {
                guardarProductos();
            } catch (IOException ignorado) {
                // Se informa el error principal.
            }

            System.out.println("No se pudo guardar la venta: " + e.getMessage());
        }
    }

    private static Producto seleccionarProducto() {

        if (productos.isEmpty()) {
            System.out.println("No hay productos registrados.");
            return null;
        }

        System.out.print("Ingrese el código del producto (0 para cancelar): ");
        String codigo = entrada.nextLine().trim();

        if (codigo.equals("0")) {
            return null;
        }

        for (Producto p : productos) {
            if (p.getCodigo().equalsIgnoreCase(codigo)) {
                return p;
            }
        }

        System.out.println("No se encontró un producto con ese código.");
        return null;
    }

    private static void consultarVentas() {

        System.out.println("\n--- REGISTRO DE VENTAS ---");

        File archivo = new File(ARCHIVO_VENTAS);

        if (!archivo.exists()) {
            System.out.println("Todavía no hay ventas registradas.");
            return;
        }

        double total = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {

            String linea;

            while ((linea = br.readLine()) != null) {

                String[] c = linea.split("\\|", -1);

                if (c.length == 7) {
                    System.out.println("Pedido " + c[0] + " | " + c[1]);
                    System.out.println(c[3] + " x " + c[4] + " = $" + c[6]);
                    System.out.println();

                    total += Double.parseDouble(c[6]);
                }
            }

            System.out.printf("TOTAL VENDIDO: $%.2f%n", total);

        } catch (Exception e) {
            System.out.println("No se pudo leer el archivo de ventas.");
        }
    }

    private static void mostrarMasVendidos() {

        System.out.println("\n--- PRODUCTOS MÁS VENDIDOS ---");

        File archivo = new File(ARCHIVO_VENTAS);

        if (!archivo.exists()) {
            System.out.println("Todavía no hay ventas registradas.");
            return;
        }

        Map<String, Integer> cantidades = new LinkedHashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {

            String linea;

            while ((linea = br.readLine()) != null) {

                String[] c = linea.split("\\|", -1);

                if (c.length == 7) {
                    int cantidad = Integer.parseInt(c[4]);

                    cantidades.put(
                            c[3],
                            cantidades.getOrDefault(c[3], 0) + cantidad
                    );
                }
            }

        } catch (Exception e) {
            System.out.println("No se pudo generar el reporte.");
            return;
        }

        if (cantidades.isEmpty()) {
            System.out.println("Todavía no hay productos vendidos.");
            return;
        }

        List<Map.Entry<String, Integer>> lista =
                new ArrayList<>(cantidades.entrySet());

        lista.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));

        for (Map.Entry<String, Integer> e : lista) {
            System.out.println(e.getKey() + ": "
                    + e.getValue() + " unidad(es)");
        }
    }

    private static void cargarProductos() {

        File archivo = new File(ARCHIVO_PRODUCTOS);

        if (!archivo.exists()) {
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {

            String linea;

            while ((linea = br.readLine()) != null) {

                String[] c = linea.split("\\|", -1);

                if (c.length == 4) {
                    try {
                        productos.add(new Producto(
                                c[0],
                                c[1],
                                Double.parseDouble(c[2]),
                                Integer.parseInt(c[3])
                        ));
                    } catch (RuntimeException e) {
                        System.out.println("Registro de producto ignorado: " + linea);
                    }
                }
            }

        } catch (IOException e) {
            System.out.println("No se pudo leer productos.txt.");
        }
    }

    private static void guardarProductos() throws IOException {

        try (BufferedWriter bw = new BufferedWriter(
                new FileWriter(ARCHIVO_PRODUCTOS))) {

            for (Producto p : productos) {
                bw.write(limpiar(p.getCodigo()) + "|"
                        + limpiar(p.getNombre()) + "|"
                        + p.getPrecio() + "|"
                        + p.getStock());

                bw.newLine();
            }
        }
    }

    private static void guardarVenta(Pedido pedido) throws IOException {

        try (BufferedWriter bw = new BufferedWriter(
                new FileWriter(ARCHIVO_VENTAS, true))) {

            for (Pedido.Detalle d : pedido.getDetalles()) {

                bw.write(pedido.getNumero() + "|"
                        + pedido.getFecha() + "|"
                        + limpiar(d.getProducto().getCodigo()) + "|"
                        + limpiar(d.getProducto().getNombre()) + "|"
                        + d.getCantidad() + "|"
                        + d.getProducto().getPrecio() + "|"
                        + String.format(Locale.US, "%.2f", d.getSubtotal()));

                bw.newLine();
            }
        }
    }

    private static void cargarNumeroPedido() {

        File archivo = new File(ARCHIVO_VENTAS);

        if (!archivo.exists()) {
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {

            String linea;

            while ((linea = br.readLine()) != null) {

                String[] c = linea.split("\\|", -1);

                if (c.length == 7) {
                    siguientePedido = Math.max(
                            siguientePedido,
                            Integer.parseInt(c[0]) + 1
                    );
                }
            }

        } catch (Exception e) {
            System.out.println("No se pudo recuperar el número del pedido.");
        }
    }

    private static String limpiar(String valor) {
        return valor.replace("|", "/")
                .replace("\n", " ")
                .replace("\r", " ")
                .trim();
    }

    private static int leerEntero(String mensaje) {

        while (true) {
            System.out.print(mensaje);
            String texto = entrada.nextLine().trim();

            try {
                return Integer.parseInt(texto);
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un número entero válido.");
            }
        }
    }

    private static double leerDecimal(String mensaje) {

        while (true) {
            System.out.print(mensaje);
            String texto = entrada.nextLine().trim().replace(',', '.');

            try {
                return Double.parseDouble(texto);
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un número válido.");
            }
        }
    }
}