package Practica_1;

import java.util.ArrayList;
import java.util.List;

public class Pedido {

    public static class Detalle {

        private final Producto producto;
        private final int cantidad;

        public Detalle(Producto producto, int cantidad) {
            if (producto == null) {
                throw new IllegalArgumentException("Seleccione un producto.");
            }

            if (cantidad <= 0) {
                throw new IllegalArgumentException(
                    "La cantidad debe ser mayor que cero."
                );
            }

            this.producto = producto;
            this.cantidad = cantidad;
        }

        public Producto getProducto() {
            return producto;
        }

        public int getCantidad() {
            return cantidad;
        }

        public double getSubtotal() {
            return producto.getPrecio() * cantidad;
        }
    }

    private final int numero;
    private final String fecha;
    private final List<Detalle> detalles = new ArrayList<>();

    public Pedido(int numero, String fecha) {
        this.numero = numero;
        this.fecha = fecha;
    }

    public void agregarProducto(Producto producto, int cantidad) {
        if (producto == null) {
            throw new IllegalArgumentException("Seleccione un producto.");
        }

        if (cantidad <= 0) {
            throw new IllegalArgumentException(
                "La cantidad debe ser mayor que cero."
            );
        }

        int cantidadAcumulada = cantidad;

        for (Detalle detalle : detalles) {
            if (detalle.getProducto() == producto) {
                cantidadAcumulada += detalle.getCantidad();
            }
        }

        if (cantidadAcumulada > producto.getStock()) {
            throw new IllegalArgumentException(
                "No hay stock suficiente de " + producto.getNombre() + "."
            );
        }

        detalles.add(new Detalle(producto, cantidad));
    }

    public int getNumero() {
        return numero;
    }

    public String getFecha() {
        return fecha;
    }

    public List<Detalle> getDetalles() {
        return new ArrayList<>(detalles);
    }

    public double calcularTotal() {
        double total = 0;

        for (Detalle detalle : detalles) {
            total += detalle.getSubtotal();
        }

        return total;
    }
}