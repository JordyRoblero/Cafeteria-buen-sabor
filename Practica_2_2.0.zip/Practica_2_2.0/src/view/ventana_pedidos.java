package view;

import model.GestorPedidos;
import model.Producto;
import model.Pedido;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class ventana_pedidos extends JFrame {

    private final GestorPedidos model;

    private JTextField txtCodigo;
    private JTextField txtNombre;
    private JTextField txtPrecio;
    private JTextField txtStock;
    private JTextField txtReposicion;

    private JTable tablaProductos;
    private DefaultTableModel modeloTabla;

    private JComboBox<Producto> comboProductos;
    private JSpinner spnCantidad;
    private JTable tablaCarrito;
    private DefaultTableModel modeloCarrito;
    private JLabel lblTotales;
    private JTextArea areaReporte;

    private final Map<String, Integer> cantidades = new LinkedHashMap<>();

    public ventana_pedidos(GestorPedidos model) {
        this.model = model;
        setTitle("Sistema de Gestión de Pedidos - El Buen Sabor");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 620);
        setMinimumSize(new Dimension(800, 550));
        setLocationRelativeTo(null);
        initComponents();
        actualizarProductos();
        actualizarCombo();
    }

    private void initComponents() {
        JPanel panelPrincipal = new JPanel(new BorderLayout(8, 8));
        panelPrincipal.setBackground(new Color(0, 0, 255));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setContentPane(panelPrincipal);

        JLabel titulo = new JLabel("GESTIÓN DE PEDIDOS | EL BUEN SABOR");
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        panelPrincipal.add(titulo, BorderLayout.NORTH);

        JTabbedPane pestañas = new JTabbedPane();
        pestañas.addTab("Productos", construirPanelProductos());
        pestañas.addTab("Nuevo pedido", construirPanelPedidos());
        pestañas.addTab("Reportes", construirPanelReportes());
        panelPrincipal.add(pestañas, BorderLayout.CENTER);
    }

    private JPanel construirPanelProductos() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBackground(new Color(0, 0, 255));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JPanel formulario = new JPanel(new GridLayout(2, 4, 8, 6));
        formulario.setBackground(new Color(128, 128, 255));
        formulario.setBorder(BorderFactory.createTitledBorder("Datos del producto"));

        txtCodigo = new JTextField();
        txtNombre = new JTextField();
        txtPrecio = new JTextField();
        txtStock = new JTextField();

        formulario.add(crearCampo("Código", txtCodigo));
        formulario.add(crearCampo("Nombre", txtNombre));
        formulario.add(crearCampo("Precio ($)", txtPrecio));
        formulario.add(crearCampo("Stock inicial", txtStock));

        JButton btnRegistrar = new JButton("Registrar");
        JButton btnEditar = new JButton("Guardar cambios");
        JButton btnLimpiar = new JButton("Limpiar");
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        botones.setBackground(new Color(128, 128, 255));
        botones.add(btnRegistrar);
        botones.add(btnEditar);
        botones.add(btnLimpiar);

        JPanel arriba = new JPanel(new BorderLayout(5, 5));
        arriba.add(formulario, BorderLayout.CENTER);
        arriba.add(botones, BorderLayout.SOUTH);
        panel.add(arriba, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new Object[]{"Código", "Producto", "Precio", "Stock"}, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        tablaProductos = new JTable(modeloTabla);
        tablaProductos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        panel.add(new JScrollPane(tablaProductos), BorderLayout.CENTER);

        txtReposicion = new JTextField(8);
        JButton btnReponer = new JButton("Reponer stock");
        JPanel reposicion = new JPanel(new FlowLayout(FlowLayout.LEFT));
        reposicion.setBackground(new Color(128, 128, 255));
        reposicion.add(new JLabel("Cantidad a reponer:"));
        reposicion.add(txtReposicion);
        reposicion.add(btnReponer);
        panel.add(reposicion, BorderLayout.SOUTH);

        tablaProductos.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tablaProductos.getSelectedRow() >= 0) {
                int fila = tablaProductos.convertRowIndexToModel(tablaProductos.getSelectedRow());
                txtCodigo.setText(modeloTabla.getValueAt(fila, 0).toString());
                txtNombre.setText(modeloTabla.getValueAt(fila, 1).toString());
                txtPrecio.setText(modeloTabla.getValueAt(fila, 2).toString());
                txtStock.setText(modeloTabla.getValueAt(fila, 3).toString());
            }
        });

        btnRegistrar.addActionListener(e -> ejecutar(() -> {
            Producto producto = new Producto(texto(txtCodigo), texto(txtNombre), decimal(txtPrecio), entero(txtStock));
            model.registrarProducto(producto);
            actualizarProductos();
            actualizarCombo();
            limpiarFormulario();
            mostrarMensaje("Producto registrado correctamente.");
        }));

        btnEditar.addActionListener(e -> ejecutar(() -> {
            model.editarProducto(texto(txtCodigo), texto(txtNombre), decimal(txtPrecio), entero(txtStock));
            actualizarProductos();
            actualizarCombo();
            mostrarMensaje("Producto actualizado correctamente.");
        }));

        btnReponer.addActionListener(e -> ejecutar(() -> {
            model.reponerStock(texto(txtCodigo), entero(txtReposicion));
            actualizarProductos();
            actualizarCombo();
            txtReposicion.setText("");
            mostrarMensaje("Stock repuesto correctamente.");
        }));

        btnLimpiar.addActionListener(e -> limpiarFormulario());
        return panel;
    }

    private JPanel construirPanelPedidos() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBackground(new Color(0, 128, 255));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JPanel selector = new JPanel(new FlowLayout(FlowLayout.LEFT));
        selector.setBackground(new Color(0, 128, 255));
        selector.setBorder(BorderFactory.createTitledBorder("Agregar productos al pedido"));
        comboProductos = new JComboBox<>();
        spnCantidad = new JSpinner(new SpinnerNumberModel(1, 1, 9999, 1));
        JButton btnAgregar = new JButton("Agregar");
        selector.add(new JLabel("Producto:"));
        selector.add(comboProductos);
        selector.add(new JLabel("Cantidad:"));
        selector.add(spnCantidad);
        selector.add(btnAgregar);
        panel.add(selector, BorderLayout.NORTH);

        modeloCarrito = new DefaultTableModel(new Object[]{"Código", "Producto", "Precio", "Cantidad", "Subtotal"}, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        tablaCarrito = new JTable(modeloCarrito);
        panel.add(new JScrollPane(tablaCarrito), BorderLayout.CENTER);

        JButton btnQuitar = new JButton("Quitar seleccionado");
        JButton btnVaciar = new JButton("Vaciar pedido");
        JButton btnConfirmar = new JButton("Confirmar pedido");
        lblTotales = new JLabel("Subtotal: $0.00 | IVA: $0.00 | Total: $0.00");
        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        acciones.setBackground(new Color(0, 128, 255));
        acciones.add(btnQuitar);
        acciones.add(btnVaciar);
        acciones.add(lblTotales);
        acciones.add(btnConfirmar);
        panel.add(acciones, BorderLayout.SOUTH);

        btnAgregar.addActionListener(e -> ejecutar(() -> {
            Producto producto = (Producto) comboProductos.getSelectedItem();
            if (producto == null) throw new IllegalArgumentException("Seleccione un producto.");
            int cantidad = (Integer) spnCantidad.getValue();
            int nuevaCantidad = cantidades.getOrDefault(producto.getCodigo(), 0) + cantidad;
            if (nuevaCantidad > producto.getStock()) throw new IllegalArgumentException("Stock insuficiente para " + producto.getNombre());
            cantidades.put(producto.getCodigo(), nuevaCantidad);
            actualizarCarrito();
        }));

        btnQuitar.addActionListener(e -> {
            int fila = tablaCarrito.getSelectedRow();
            if (fila < 0) {
                mostrarAdvertencia("Seleccione un producto del pedido.");
                return;
            }
            fila = tablaCarrito.convertRowIndexToModel(fila);
            cantidades.remove(modeloCarrito.getValueAt(fila, 0).toString());
            actualizarCarrito();
        });

        btnVaciar.addActionListener(e -> {
            cantidades.clear();
            actualizarCarrito();
        });

        btnConfirmar.addActionListener(e -> ejecutar(() -> {
            if (cantidades.isEmpty()) throw new IllegalArgumentException("Agregue productos antes de confirmar.");
            int respuesta = JOptionPane.showConfirmDialog(this, "¿Desea confirmar este pedido?", "Confirmar pedido", JOptionPane.YES_NO_OPTION);
            if (respuesta != JOptionPane.YES_OPTION) return;
            Pedido pedido = model.confirmarPedido(cantidades);
            cantidades.clear();
            actualizarCarrito();
            actualizarProductos();
            actualizarCombo();
            mostrarMensaje("Pedido " + pedido.getCodigo() + " registrado correctamente.\nSubtotal: " + dinero(pedido.getSubtotal())
                    + "\nIVA: " + dinero(pedido.getIva()) + "\nTotal: " + dinero(pedido.getTotal()));
        }));
        return panel;
    }

    private JPanel construirPanelReportes() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBackground(new Color(128, 255, 255));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        JButton btnGenerar = new JButton("Generar reporte de ventas");
        areaReporte = new JTextArea();
        areaReporte.setEditable(false);
        areaReporte.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        panel.add(btnGenerar, BorderLayout.NORTH);
        panel.add(new JScrollPane(areaReporte), BorderLayout.CENTER);
        btnGenerar.addActionListener(e -> ejecutar(() -> areaReporte.setText(model.generarReporte())));
        return panel;
    }

    private JPanel crearCampo(String titulo, JTextField campo) {
        JPanel panel = new JPanel(new BorderLayout(3, 3));
        panel.add(new JLabel(titulo), BorderLayout.NORTH);
        panel.add(campo, BorderLayout.CENTER);
        return panel;
    }

    private void actualizarProductos() {
        if (modeloTabla == null) return;
        modeloTabla.setRowCount(0);
        for (Producto p : model.listarProductos()) {
            modeloTabla.addRow(new Object[]{p.getCodigo(), p.getNombre(), String.format(java.util.Locale.US, "%.2f", p.getPrecio()), p.getStock()});
        }
    }

    private void actualizarCombo() {
        if (comboProductos == null) return;
        String seleccionado = null;
        Producto actual = (Producto) comboProductos.getSelectedItem();
        if (actual != null) seleccionado = actual.getCodigo();
        comboProductos.removeAllItems();
        for (Producto p : model.listarProductos()) {
            comboProductos.addItem(p);
            if (p.getCodigo().equals(seleccionado)) comboProductos.setSelectedItem(p);
        }
    }

    private void actualizarCarrito() {
        modeloCarrito.setRowCount(0);
        double subtotal = 0;
        for (Map.Entry<String, Integer> entrada : cantidades.entrySet()) {
            Producto p = model.buscarProducto(entrada.getKey());
            if (p == null) continue;
            int cantidad = entrada.getValue();
            double valor = p.getPrecio() * cantidad;
            subtotal += valor;
            modeloCarrito.addRow(new Object[]{p.getCodigo(), p.getNombre(), dinero(p.getPrecio()), cantidad, dinero(valor)});
        }
        double iva = subtotal * Pedido.IVA;
        lblTotales.setText("Subtotal: " + dinero(subtotal) + " | IVA: " + dinero(iva) + " | Total: " + dinero(subtotal + iva));
    }

    private String texto(JTextField campo) { return campo.getText().trim(); }
    private double decimal(JTextField campo) {
        try { return Double.parseDouble(texto(campo)); }
        catch (NumberFormatException ex) { throw new IllegalArgumentException("Ingrese un precio válido."); }
    }
    private int entero(JTextField campo) {
        try { return Integer.parseInt(texto(campo)); }
        catch (NumberFormatException ex) { throw new IllegalArgumentException("Ingrese una cantidad entera válida."); }
    }
    private String dinero(double valor) { return String.format(java.util.Locale.US, "$%.2f", valor); }

    private void limpiarFormulario() {
        txtCodigo.setText("");
        txtNombre.setText("");
        txtPrecio.setText("");
        txtStock.setText("");
        txtReposicion.setText("");
        tablaProductos.clearSelection();
    }

    private void mostrarMensaje(String texto) {
        JOptionPane.showMessageDialog(this, texto, "Información", JOptionPane.INFORMATION_MESSAGE);
    }
    private void mostrarAdvertencia(String texto) {
        JOptionPane.showMessageDialog(this, texto, "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
    private void ejecutar(Runnable accion) {
        try { accion.run(); }
        catch (IllegalArgumentException ex) { mostrarAdvertencia(ex.getMessage()); }
        catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Ocurrió un error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
}
