package model;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class GestorPedidos {
    private final File archivoProductos;
    private final File archivoVentas;
    private final ArrayList<Producto> productos = new ArrayList<>();
    private int siguientePedido = 1;
    private static final DateTimeFormatter FORMATO =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public GestorPedidos() {
        this(new File("productos.txt"), new File("ventas.txt"));
    }
    public GestorPedidos(File p, File v) {
        archivoProductos = p;
        archivoVentas = v;

        cargarProductos();
        cargarNumeroPedido();
    }
    private void asegurarCarpeta(File f) throws IOException {

        File d = f.getAbsoluteFile().getParentFile();

        if (d != null && !d.exists() && !d.mkdirs()) {
            throw new IOException("No se pudo crear carpeta.");
        }
    }
    private void cargarProductos() {

        productos.clear();

        if (!archivoProductos.exists()) {
            return;
        }

        try (BufferedReader br = Files.newBufferedReader(
                archivoProductos.toPath(),
                StandardCharsets.UTF_8)) {

            String l;

            while ((l = br.readLine()) != null) {

                String[] c = l.split("\\|", -1);

                if (c.length == 4) {
                    try {
                        productos.add(new Producto(
                                c[0],
                                c[1],
                                Double.parseDouble(c[2]),
                                Integer.parseInt(c[3])
                        ));

                    } catch (RuntimeException ex) {
                        System.err.println(
                                "Producto inválido omitido: " + l
                        );
                    }
                }
            }

        } catch (IOException e) {
            throw new IllegalStateException(
                    "Error leyendo productos.txt: " + e.getMessage(), e
            );
        }
    }
    private void guardarProductos() {

        try {
            asegurarCarpeta(archivoProductos);

            try (BufferedWriter bw = Files.newBufferedWriter(
                    archivoProductos.toPath(),
                    StandardCharsets.UTF_8)) {

                for (Producto p : productos) {

                    bw.write(
                            limpiar(p.getCodigo()) + "|"
                            + limpiar(p.getNombre()) + "|"
                            + p.getPrecio() + "|"
                            + p.getStock()
                    );

                    bw.newLine();
                }
            }

        } catch (IOException e) {
            throw new IllegalStateException(
                    "Error guardando productos: " + e.getMessage(), e
            );
        }
    }
    private void cargarNumeroPedido() {

        if (!archivoVentas.exists()) {
            return;
        }

        try (BufferedReader br = Files.newBufferedReader(
                archivoVentas.toPath(),
                StandardCharsets.UTF_8)) {

            String l;

            while ((l = br.readLine()) != null) {

                String[] c = l.split("\\|", -1);

                if (c.length == 7) {
                    try {
                        siguientePedido = Math.max(
                                siguientePedido,
                                Integer.parseInt(c[0]) + 1
                        );

                    } catch (NumberFormatException ignored) {
                    }
                }
            }

        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }
    public ArrayList<Producto> listarProductos() {
        return new ArrayList<>(productos);
    }
    public Producto buscarProducto(String codigo) {

        for (Producto p : productos) {

            if (p.getCodigo().equalsIgnoreCase(codigo.trim())) {
                return p;
            }
        }

        return null;
    }

    public void registrarProducto(Producto p) {

        if (p == null) {
            throw new IllegalArgumentException("Producto inválido.");
        }

        if (buscarProducto(p.getCodigo()) != null) {
            throw new IllegalArgumentException(
                    "Ya existe un producto con ese código."
            );
        }

        UtilGenerico.agregarVarios(productos, p);

        guardarProductos();
    }
    public void editarProducto(
            String codigo,
            String nombre,
            double precio,
            int stock) {

        Producto p = buscarProducto(codigo);

        if (p == null) {
            throw new IllegalArgumentException(
                    "Seleccione un producto existente."
            );
        }

        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "El nombre es obligatorio."
            );
        }

        if (!Double.isFinite(precio) || precio <= 0 || stock < 0) {
            throw new IllegalArgumentException(
                    "Precio debe ser positivo y stock no negativo."
            );
        }

        p.setNombre(nombre.trim());
        p.setPrecio(precio);
        p.setStock(stock);

        guardarProductos();
    }

    public void reponerStock(String codigo, int n) {

        Producto p = buscarProducto(codigo);

        if (p == null) {
            throw new IllegalArgumentException(
                    "Producto no encontrado."
            );
        }

        if (n <= 0) {
            throw new IllegalArgumentException(
                    "La reposición debe ser mayor que cero."
            );
        }

        p.setStock(p.getStock() + n);

        guardarProductos();
    }
    public Pedido confirmarPedido(Map<String, Integer> cantidades) {

        if (cantidades == null || cantidades.isEmpty()) {
            throw new IllegalArgumentException(
                    "Agregue al menos un producto."
            );
        }

        ArrayList<ItemPedido> items = UtilGenerico.crearLista();

        for (Map.Entry<String, Integer> e : cantidades.entrySet()) {

            Producto p = buscarProducto(e.getKey());

            int n = e.getValue() == null ? 0 : e.getValue();

            if (p == null) {
                throw new IllegalArgumentException(
                        "Producto no encontrado: " + e.getKey()
                );
            }

            if (n <= 0) {
                throw new IllegalArgumentException(
                        "Cantidad inválida."
                );
            }

            if (n > p.getStock()) {
                throw new IllegalArgumentException(
                        "Stock insuficiente para " + p.getNombre()
                        + ". Disponible: " + p.getStock()
                );
            }

            items.add(new ItemPedido(p, n));
        }

        String num = String.valueOf(siguientePedido);

        Pedido pedido = new Pedido(num, items);

        for (ItemPedido i : items) {
            i.getProducto().setStock(
                    i.getProducto().getStock() - i.getCantidad()
            );
        }

        guardarProductos();

        try {

            asegurarCarpeta(archivoVentas);

            try (BufferedWriter bw = Files.newBufferedWriter(
                    archivoVentas.toPath(),
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND)) {

                for (ItemPedido i : items) {

                    bw.write(
                            num + "|"
                            + pedido.fechaTexto() + "|"
                            + limpiar(i.getProducto().getCodigo()) + "|"
                            + limpiar(i.getProducto().getNombre()) + "|"
                            + i.getCantidad() + "|"
                            + String.format(
                                    Locale.US,
                                    "%.2f",
                                    i.getProducto().getPrecio()
                            ) + "|"
                            + String.format(
                                    Locale.US,
                                    "%.2f",
                                    i.getSubtotal()
                            )
                    );

                    bw.newLine();
                }
            }

        } catch (IOException ex) {

            for (ItemPedido i : items) {

                i.getProducto().setStock(
                        i.getProducto().getStock() + i.getCantidad()
                );
            }

            guardarProductos();

            throw new IllegalStateException(
                    "No se pudo guardar venta: " + ex.getMessage(), ex
            );
        }

        siguientePedido++;

        return pedido;
    }

    // Generar reporte de ventas
    public String generarReporte() {

        double total = 0;

        Map<String, Integer> demanda = new LinkedHashMap<>();

        LocalDate hoy = LocalDate.now();

        if (archivoVentas.exists()) {

            try (BufferedReader br = Files.newBufferedReader(
                    archivoVentas.toPath(),
                    StandardCharsets.UTF_8)) {

                String l;

                while ((l = br.readLine()) != null) {

                    String[] c = l.split("\\|", -1);

                    if (c.length != 7) {
                        continue;
                    }

                    try {

                        if (LocalDateTime.parse(
                                c[1], FORMATO
                        ).toLocalDate().equals(hoy)) {

                            total += Double.parseDouble(c[6]);

                            demanda.merge(
                                    c[3],
                                    Integer.parseInt(c[4]),
                                    Integer::sum
                            );
                        }

                    } catch (RuntimeException ignored) {
                    }
                }

            } catch (IOException e) {

                throw new IllegalStateException(
                        "Error leyendo ventas: " + e.getMessage(), e
                );
            }
        }
        StringBuilder sb = new StringBuilder(
                "EL BUEN SABOR - REPORTE DE VENTAS\n"
                + "Fecha: " + hoy + "\n"
                + "Ventas del día: "
                + String.format(Locale.US, "$%.2f", total)
                + "\n\nPRODUCTOS MÁS VENDIDOS\n"
        );

        if (demanda.isEmpty()) {

            sb.append("No hay ventas registradas hoy.\n");

        } else {

            ArrayList<Map.Entry<String, Integer>> l =
                    new ArrayList<>(demanda.entrySet());

            l.sort(
                    Map.Entry.<String, Integer>comparingByValue(
                            Comparator.reverseOrder()
                    )
            );

            for (Map.Entry<String, Integer> e : l) {

                sb.append(e.getKey())
                        .append(": ")
                        .append(e.getValue())
                        .append(" unidad(es)\n");
            }
        }

        return sb.toString();
    }
    private String limpiar(String s) {

        return s.replace("|", "/")
                .replace("\n", " ")
                .replace("\r", " ")
                .trim();
    }
}