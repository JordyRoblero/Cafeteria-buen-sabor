package model;

import java.util.ArrayList;

public final class UtilGenerico {
    private UtilGenerico() {}

    @SafeVarargs
    public static <T> ArrayList<T> crearLista(T... elementos) {
        ArrayList<T> lista = new ArrayList<>();
        if (elementos != null) {
            for (T elemento : elementos) lista.add(elemento);
        }
        return lista;
    }

    @SafeVarargs
    public static <T> void agregarVarios(ArrayList<T> lista, T... elementos) {
        if (lista == null) throw new IllegalArgumentException("La lista no puede ser null");
        if (elementos != null) {
            for (T elemento : elementos) lista.add(elemento);
        }
    }
}
