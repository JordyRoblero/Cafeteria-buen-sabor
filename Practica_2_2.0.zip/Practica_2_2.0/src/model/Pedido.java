package model;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
public class Pedido {
 public static final double IVA = 0.15;
 private final String codigo; 
 private final LocalDateTime fecha;
 private final ArrayList<ItemPedido> items; 
 private final double subtotal;
 public Pedido(String codigo, ArrayList<ItemPedido> items){
	 this.codigo=codigo;this.fecha=LocalDateTime.now();
	 this.items=new ArrayList<>(items);
	 double s=0;for(ItemPedido i:items)s+=i.getSubtotal();
	 subtotal=s;
	 }
 public String getCodigo(){
	 return codigo;
	 } 
 LocalDateTime getFecha(){
	  return fecha;} public ArrayList<ItemPedido> getItems(){
		  return new ArrayList<>(items);
		  } 
	  public double getSubtotal(){
			  return subtotal;} public double getIva(){
				  return subtotal*IVA;
				  }
			  public double getTotal(){
				  return subtotal+getIva();
				  }
 public String fechaTexto(){
	 return fecha.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
	 }
}
