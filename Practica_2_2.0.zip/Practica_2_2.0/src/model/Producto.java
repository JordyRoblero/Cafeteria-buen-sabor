package model;

public class Producto {
    private String codigo;
    private String nombre;
    private double precio;
    private int stock;

    public Producto(String codigo, String nombre, double precio, int stock) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
    }
    public String getCodigo() { 
    	return codigo; 
    }
    public String getNombre() { 
    	return nombre; 
    }
    public double getPrecio() { 
    	return precio; 
    }
    public int getStock() { 
    	return stock; 
    }
    public void setNombre(String nombre) { 
    	this.nombre = nombre; 
    }
    
    public void setPrecio(double precio) { 
    	if (!Double.isFinite(precio) || precio <= 0) throw new IllegalArgumentException("El precio debe ser mayor que cero."); this.precio = precio;
    }
    public void setStock(int stock) { if (stock < 0) throw new IllegalArgumentException("El stock no puede ser negativo."); 
    this.stock = stock; 
    }
    @Override public String toString() { 
    	return codigo + " - " + nombre; 
    	}
    public String toLinea() {
        return codigo.replace("|"," ") + "|" + nombre.replace("|"," ") + "|" + precio + "|" + stock;
    }
    public static Producto desdeLinea(String linea) {
        String[] p = linea.split("\\|", -1);
        if (p.length != 4) throw new IllegalArgumentException("Formato de producto inválido");
        return new Producto(p[0], p[1], Double.parseDouble(p[2]), Integer.parseInt(p[3]));
    }
}
