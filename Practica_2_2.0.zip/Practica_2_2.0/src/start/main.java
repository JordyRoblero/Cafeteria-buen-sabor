package start;

import javax.swing.SwingUtilities;
import view.ventana_pedidos;
import model.GestorPedidos;

public class main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GestorPedidos gestor = new GestorPedidos();
            ventana_pedidos ventana = new ventana_pedidos(gestor);
            ventana.setVisible(true);
        });
    }
}