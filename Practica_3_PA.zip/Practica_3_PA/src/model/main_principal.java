package model;

import javax.swing.SwingUtilities;

import controller.GestorPedidos;
import view.pedidos_view;

public class main_principal {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            GestorPedidos gestor = new GestorPedidos();

            pedidos_view ventana = new pedidos_view(gestor);

            ventana.setVisible(true);

        });
    }
}
