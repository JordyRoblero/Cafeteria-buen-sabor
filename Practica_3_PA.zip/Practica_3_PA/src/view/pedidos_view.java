package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.FlowLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import controller.GestorPedidos;
import controller.Producto;
import controller.Pedido;
import controller.ItemPedido;

public class pedidos_view extends JFrame {

    private GestorPedidos gestor;

    private DefaultTableModel modeloProductos;
    private DefaultTableModel modeloPedido;

    private JTable tablaProductos;
    private JTable tablaPedido;

    private Pedido pedido;

    private final Color VERDE = new Color(35, 110, 75);
    private final Color FONDO = new Color(245, 248, 245);
    private final Color BLANCO = Color.WHITE;

    public pedidos_view(GestorPedidos gestor) {

        this.gestor = gestor;

        setTitle("Cafetería Universitaria - El Buen Sabor");
        setSize(950, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        construirInterfaz();
        actualizarProductos();
        nuevoPedido();
    }

    private void construirInterfaz() {

        JPanel principal = new JPanel(new BorderLayout(12, 12));
        principal.setBackground(FONDO);
        principal.setBorder(
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );

        JLabel titulo = new JLabel(
            "CAFETERÍA UNIVERSITARIA - EL BUEN SABOR",
            SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 22));
        titulo.setForeground(VERDE);

        principal.add(titulo, BorderLayout.NORTH);

        JPanel centro = new JPanel(new GridLayout(1, 2, 15, 0));
        centro.setBackground(FONDO);

        JPanel panelProductos = new JPanel(new BorderLayout(8, 8));
        panelProductos.setBackground(BLANCO);
        panelProductos.setBorder(
            BorderFactory.createTitledBorder("PRODUCTOS DISPONIBLES")
        );

        modeloProductos = new DefaultTableModel(
            new Object[]{"Código", "Producto", "Precio", "Stock"}, 0
        ) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        tablaProductos = new JTable(modeloProductos);
        panelProductos.add(
            new JScrollPane(tablaProductos),
            BorderLayout.CENTER
        );

        JPanel botonesProductos = new JPanel(new FlowLayout());

        agregarBoton(botonesProductos, "Registrar", e -> registrarProducto());
        agregarBoton(botonesProductos, "Modificar", e -> modificarProducto());
        agregarBoton(botonesProductos, "Reponer stock", e -> reponerStock());

        panelProductos.add(botonesProductos, BorderLayout.SOUTH);

        JPanel panelPedido = new JPanel(new BorderLayout(8, 8));
        panelPedido.setBackground(BLANCO);
        panelPedido.setBorder(
            BorderFactory.createTitledBorder("PEDIDO ACTUAL")
        );

        modeloPedido = new DefaultTableModel(
            new Object[]{"Producto", "Cantidad", "Subtotal"}, 0
        ) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        tablaPedido = new JTable(modeloPedido);

        panelPedido.add(
            new JScrollPane(tablaPedido),
            BorderLayout.CENTER
        );

        JPanel botonesPedido = new JPanel(new FlowLayout());

        agregarBoton(botonesPedido, "Agregar producto", e -> agregarProducto());
        agregarBoton(botonesPedido, "Confirmar venta", e -> confirmarVenta());
        agregarBoton(botonesPedido, "Nuevo pedido", e -> nuevoPedido());

        panelPedido.add(botonesPedido, BorderLayout.SOUTH);

        centro.add(panelProductos);
        centro.add(panelPedido);

        principal.add(centro, BorderLayout.CENTER);

        JPanel inferior = new JPanel(new FlowLayout(FlowLayout.CENTER));
        inferior.setBackground(FONDO);

        agregarBoton(inferior, "Reporte de ventas", e -> mostrarReporte());
        agregarBoton(inferior, "Salir", e -> dispose());

        principal.add(inferior, BorderLayout.SOUTH);

        setContentPane(principal);
    }
    private void agregarBoton(
        JPanel panel,
        String texto,
        java.awt.event.ActionListener accion
    ) {

        JButton boton = new JButton(texto);

        boton.setFont(new Font("Arial", Font.BOLD, 12));
        boton.setBackground(VERDE);
        boton.setForeground(BLANCO);
        boton.setFocusPainted(false);

        boton.addActionListener(accion);

        panel.add(boton);
    }
    private String pedirDato(String mensaje) {
        return JOptionPane.showInputDialog(this, mensaje);
    }
    private void registrarProducto() {

        try {

            int codigo = Integer.parseInt(pedirDato("Ingrese el código:"));
            String nombre = pedirDato("Ingrese el nombre:");
            double precio = Double.parseDouble(pedirDato("Ingrese el precio:"));
            int stock = Integer.parseInt(pedirDato("Ingrese el stock inicial:"));

            gestor.registrar(codigo, nombre, precio, stock);

            actualizarProductos();

            JOptionPane.showMessageDialog(this, "Producto registrado correctamente.");

        } catch (Exception e) {
            mostrarError(e);
        }
    }
    private void modificarProducto() {

        try {

            int codigo = Integer.parseInt(pedirDato("Código del producto:"));
            String nombre = pedirDato("Nuevo nombre:");
            double precio = Double.parseDouble(pedirDato("Nuevo precio:"));

            gestor.modificar(codigo, nombre, precio);

            actualizarProductos();

            JOptionPane.showMessageDialog(this, "Producto modificado correctamente.");

        } catch (Exception e) {
            mostrarError(e);
        }
    }
    private void reponerStock() {

        try {

            int codigo = Integer.parseInt(pedirDato("Código del producto:"));
            int cantidad = Integer.parseInt(pedirDato("Cantidad a reponer:"));

            gestor.reponer(codigo, cantidad);

            actualizarProductos();

            JOptionPane.showMessageDialog(this, "Stock actualizado correctamente.");

        } catch (Exception e) {
            mostrarError(e);
        }
    }
    private void agregarProducto() {

        try {

            int fila = tablaProductos.getSelectedRow();

            if (fila == -1) {
                throw new Exception("Seleccione un producto de la tabla.");
            }

            fila = tablaProductos.convertRowIndexToModel(fila);

            int codigo = (int) modeloProductos.getValueAt(fila, 0);

            Producto producto = gestor.buscar(codigo);

            int cantidad = Integer.parseInt(pedirDato("Ingrese la cantidad:"));

            int cantidadAgregada = 0;

            for (ItemPedido item : pedido.getItems()) {

                if (item.getProducto().getCodigo() == codigo) {
                    cantidadAgregada += item.getCantidad();
                }
            }

            if (cantidad <= 0 ||
                producto.getStock() < cantidadAgregada + cantidad) {

                throw new Exception("Cantidad inválida o stock insuficiente.");
            }

            pedido.agregarProducto(producto, cantidad);

            actualizarTablaPedido();

        } catch (Exception e) {
            mostrarError(e);
        }
    }
    private void confirmarVenta() {

        try {

            gestor.confirmar(pedido);

            JOptionPane.showMessageDialog(
                this,
                "VENTA CONFIRMADA\n\n"
                + "Subtotal: $" + String.format("%.2f", pedido.calcularSubtotal())
                + "\nIVA (15%): $" + String.format("%.2f", pedido.calcularIva())
                + "\nTOTAL: $" + String.format("%.2f", pedido.calcularTotal()),
                "Venta registrada",
                JOptionPane.INFORMATION_MESSAGE
            );

            actualizarProductos();
            nuevoPedido();

        } catch (Exception e) {
            mostrarError(e);
        }
    }
    private void nuevoPedido() {

        if (pedido != null && !pedido.getItems().isEmpty()) {

            int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Desea descartar el pedido actual y crear uno nuevo?",
                "Nuevo pedido",
                JOptionPane.YES_NO_OPTION
            );

            if (opcion != JOptionPane.YES_OPTION) {
                return;
            }
        }
        pedido = gestor.nuevoPedido();

        actualizarTablaPedido();

        JOptionPane.showMessageDialog(
            this,
            "Se ha creado un nuevo pedido correctamente.",
            "Nuevo pedido",
            JOptionPane.INFORMATION_MESSAGE
        );
    }
    private void actualizarProductos() {

        modeloProductos.setRowCount(0);

        for (Producto producto : gestor.getProductos()) {

            modeloProductos.addRow(new Object[]{
                producto.getCodigo(),
                producto.getNombre(),
                String.format("%.2f", producto.getPrecio()),
                producto.getStock()
            });
        }
    }
    private void actualizarTablaPedido() {

        modeloPedido.setRowCount(0);

        for (ItemPedido item : pedido.getItems()) {

            modeloPedido.addRow(new Object[]{
                item.getProducto().getNombre(),
                item.getCantidad(),
                String.format("%.2f", item.calcularSubtotal())
            });
        }
    }
    private void mostrarReporte() {

        JOptionPane.showMessageDialog(
            this,
            gestor.reporte(),
            "Reporte de ventas",
            JOptionPane.INFORMATION_MESSAGE
        );
    }
    private void mostrarError(Exception e) {

        JOptionPane.showMessageDialog(
            this,
            e.getMessage() == null ? "Verifique los datos ingresados." : e.getMessage(),
            "Mensaje de atención",
            JOptionPane.WARNING_MESSAGE
        );
    }
}
