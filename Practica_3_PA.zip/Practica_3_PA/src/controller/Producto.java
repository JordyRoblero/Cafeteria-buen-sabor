package controller;

public class Producto {

    private int codigo;
    private String nombre;
    private double precio;
    private int stock;

    public Producto(int codigo, String nombre, double precio, int stock) {

        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public int getStock() {
        return stock;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void actualizarStock(int cantidad) {

        if (stock + cantidad < 0) {
            throw new IllegalArgumentException("Stock insuficiente.");
        }

        stock += cantidad;
    }

    public String toFile() {

        return codigo + ";"
                + nombre.replace(";", ",") + ";"
                + precio + ";"
                + stock;
    }

    public static Producto fromFile(String linea) {

        String[] datos = linea.split(";", -1);

        if (datos.length != 4) {
            throw new IllegalArgumentException("Formato de producto inválido.");
        }

        return new Producto(
            Integer.parseInt(datos[0]),
            datos[1],
            Double.parseDouble(datos[2]),
            Integer.parseInt(datos[3])
        );
    }
}
