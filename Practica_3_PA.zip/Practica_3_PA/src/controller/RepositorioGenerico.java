package controller;

import java.util.ArrayList;
import java.util.List;

public class RepositorioGenerico<T> {

    private List<T> datos = new ArrayList<>();

    public void agregar(T elemento) {
        datos.add(elemento);
    }

    public List<T> obtenerTodos() {
        return new ArrayList<>(datos);
    }

    @SafeVarargs
    public final void agregarVarios(T... elementos) {

        for (T elemento : elementos) {
            datos.add(elemento);
        }
    }

}
