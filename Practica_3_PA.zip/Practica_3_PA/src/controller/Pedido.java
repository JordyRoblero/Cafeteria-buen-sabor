package controller;

import java.util.ArrayList;
import java.util.List;

public class Pedido {

    private int numero;
    private List<ItemPedido> items = new ArrayList<>();

    public Pedido(int numero) {
        this.numero = numero;
    }

    public int getNumero() {
        return numero;
    }

    public List<ItemPedido> getItems() {
        return items;
    }

    public void agregarProducto(Producto producto, int cantidad) {

        items.add(new ItemPedido(producto, cantidad));
    }

    public double calcularSubtotal() {

        double subtotal = 0;

        for (ItemPedido item : items) {
            subtotal += item.calcularSubtotal();
        }

        return subtotal;
    }

    public double calcularIva() {

        return calcularSubtotal() * 0.15;
    }

    public double calcularTotal() {

        return calcularSubtotal() + calcularIva();
    }
}
