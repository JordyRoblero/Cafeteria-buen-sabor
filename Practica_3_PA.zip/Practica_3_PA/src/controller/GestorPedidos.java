
package controller;

import model.*;
import java.util.*;
import java.nio.file.*;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class GestorPedidos {

    private List<Producto> productos = new ArrayList<>();
    private List<String> ventas = new ArrayList<>();

    private int numero = 1;

    private Path fp = Paths.get("productos.txt");
    private Path fv = Paths.get("ventas.txt");

    public GestorPedidos() {

        cargarProductos();

        try {

            if (Files.exists(fv)) {
                ventas.addAll(Files.readAllLines(fv));
            }

            numero = ventas.size() + 1;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public Producto buscar(int codigo) {

        for (Producto producto : productos) {

            if (producto.getCodigo() == codigo) {
                return producto;
            }
        }

        return null;
    }

    public void registrar(int codigo, String nombre, double precio, int stock) {

        if (nombre == null || nombre.trim().isEmpty()
                || precio <= 0 || stock < 0 || buscar(codigo) != null) {

            throw new IllegalArgumentException(
                "Datos inválidos o código repetido."
            );
        }

        productos.add(new Producto(codigo, nombre.trim(), precio, stock));

        guardarProductos();
    }

    public void modificar(int codigo, String nombre, double precio) {

        Producto producto = buscar(codigo);

        if (producto == null || nombre == null
                || nombre.trim().isEmpty() || precio <= 0) {

            throw new IllegalArgumentException("Datos inválidos.");
        }

        producto.setNombre(nombre.trim());
        producto.setPrecio(precio);

        guardarProductos();
    }

    public void reponer(int codigo, int cantidad) {

        Producto producto = buscar(codigo);

        if (producto == null || cantidad <= 0) {
            throw new IllegalArgumentException(
                "Código o cantidad inválidos."
            );
        }

        producto.actualizarStock(cantidad);

        guardarProductos();
    }

    public Pedido nuevoPedido() {
        return new Pedido(numero++);
    }

    public void confirmar(Pedido pedido) {

        if (pedido == null || pedido.getItems().isEmpty()) {
            throw new IllegalArgumentException("Pedido vacío.");
        }

        for (ItemPedido item : pedido.getItems()) {

            Producto producto = buscar(
                item.getProducto().getCodigo()
            );

            if (producto == null || producto.getStock() < item.getCantidad()) {

                throw new IllegalArgumentException(
                    "Stock insuficiente: " + item.getProducto().getNombre()
                );
            }
        }

        for (ItemPedido item : pedido.getItems()) {

            Producto producto = buscar(
                item.getProducto().getCodigo()
            );

            producto.actualizarStock(-item.getCantidad());
        }

        guardarProductos();

        String detalle = "Pedido " + pedido.getNumero()
                + " | " + LocalDateTime.now().format(
                    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
                )
                + " | Subtotal: $" + String.format("%.2f", pedido.calcularSubtotal())
                + " | IVA: $" + String.format("%.2f", pedido.calcularIva())
                + " | Total: $" + String.format("%.2f", pedido.calcularTotal());

        try {

            Files.write(
                fv,
                Arrays.asList(detalle),
                StandardOpenOption.CREATE,
                StandardOpenOption.APPEND
            );

            ventas.add(detalle);

        } catch (IOException e) {
            throw new RuntimeException(
                "No se pudo guardar la venta.", e
            );
        }
    }

    public void guardarProductos() {

        try (BufferedWriter writer = Files.newBufferedWriter(fp)) {

            for (Producto producto : productos) {

                writer.write(producto.toFile());
                writer.newLine();
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void cargarProductos() {

        if (!Files.exists(fp)) {
            return;
        }

        try {

            for (String linea : Files.readAllLines(fp)) {

                try {
                    productos.add(Producto.fromFile(linea));

                } catch (Exception e) {
                   
                }
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public String reporte() {

        if (ventas.isEmpty()) {
            return "No hay ventas registradas.";
        }

        return String.join("\n", ventas);
    }

    @SafeVarargs
    public final <T> String unir(T... valores) {

        StringJoiner resultado = new StringJoiner(", ");

        for (T valor : valores) {
            resultado.add(String.valueOf(valor));
        }

        return resultado.toString();
    }
}
